const data = [
    {
        heading:"My Heading",
        time:"2000-2004",
        title: "Computer Science",
        university: "International University",
        desc:"Lisque persius interesset his et, in quot quidam persequeris vim, ad mea essent possim iriure."
    },
    {
        heading:"My Heading",
        time:"2005-2008",
        title: "Bachelor Degree",
        university: "University of California",
        desc:"Lisque persius interesset his et, in quot quidam persequeris vim, ad mea essent possim iriure."
    },
    {
        heading:"My Heading",
        time:"2009 - 2012",
        title: "Master Degree",
        university: "Harvard University",
        desc:"Lisque persius interesset his et, in quot quidam persequeris vim, ad mea essent possim iriure."
    },
    {
        heading:"My Heading",
        time:"2015-2016",
        title: "Jr. UI UX Designer",
        university: "International University",
        desc:"Lisque persius interesset his et, in quot quidam persequeris vim, ad mea essent possim iriure."
    },
    {
        heading:"My Heading",
        time:"2017-2016",
        title: "Jr. Product Designer",
        university: "International University",
        desc:"Lisque persius interesset his et, in quot quidam persequeris vim, ad mea essent possim iriure."
    },
    {
        heading:"My Heading",
        time:"2020-2022",
        title: "Product Designer",
        university: "International University",
        desc:"Lisque persius interesset his et, in quot quidam persequeris vim, ad mea essent possim iriure."
    }
]

export default data;